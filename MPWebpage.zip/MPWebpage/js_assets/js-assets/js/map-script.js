document.addEventListener('DOMContentLoaded', function() {
    // Check if map container exists
    const mapContainer = document.getElementById('map');
    
    if (mapContainer) {
        // Initialize map (replace with your location)
        const map = L.map('map').setView([-26.2041, 28.0473], 13); // Johannesburg
        
        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);
        
        // Add marker for your company
        L.marker([-26.2041, 28.0473])
            .addTo(map)
            .bindPopup(`
                <strong>ABC Construction</strong><br>
                123 Main Street, Johannesburg<br>
                📞 011 123 4567
            `)
            .openPopup();
    }
});