document.addEventListener('DOMContentLoaded', function() {
    
    // ===== ACCORDION FOR SERVICES =====
    const accordions = document.querySelectorAll('.accordion');
    
    accordions.forEach(accordion => {
        accordion.addEventListener('click', function() {
            this.classList.toggle('active');
            const panel = this.nextElementSibling;
            if (panel.style.display === 'block') {
                panel.style.display = 'none';
            } else {
                panel.style.display = 'block';
            }
        });
    });
    
    // ===== TABS FOR PRODUCTS =====
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active from all
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active to clicked
            this.classList.add('active');
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // ===== MODALS FOR PROJECTS =====
    const modalTriggers = document.querySelectorAll('.open-modal');
    const modal = document.getElementById('projectModal');
    const closeBtn = document.querySelector('.close-modal');
    
    if (modalTriggers.length > 0) {
        modalTriggers.forEach(trigger => {
            trigger.addEventListener('click', function() {
                modal.style.display = 'block';
                document.body.style.overflow = 'hidden';
                
                // Get project info
                const projectTitle = this.getAttribute('data-title') || 'Construction Project';
                const projectDesc = this.getAttribute('data-desc') || 'Quality construction services';
                
                document.getElementById('modalTitle').textContent = projectTitle;
                document.getElementById('modalDesc').textContent = projectDesc;
            });
        });
    }
    
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    }
    
    // Close modal when clicking outside
    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });
});