// FORM VALIDATION FOR ENQUIRIES.HTML
document.addEventListener('DOMContentLoaded', function() {
    const enquiryForm = document.getElementById('enquiryForm');
    
    if (enquiryForm) {
        enquiryForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const service = document.getElementById('service').value;
            const message = document.getElementById('message').value.trim();
            
            // Validation
            let errors = [];
            
            if (name.length < 2) {
                errors.push('Please enter your full name');
            }
            
            if (!email.includes('@') || !email.includes('.')) {
                errors.push('Please enter a valid email address');
            }
            
            if (phone.length < 10) {
                errors.push('Please enter a valid phone number (10+ digits)');
            }
            
            if (service === '') {
                errors.push('Please select a service');
            }
            
            if (message.length < 10) {
                errors.push('Please provide more details (at least 10 characters)');
            }
            
            // Show errors or process
            if (errors.length > 0) {
                showErrors(errors);
            } else {
                processEnquiry(name, email, phone, service, message);
            }
        });
    }
    
    // VALIDATION FOR CONTACT.HTML
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('contactName').value.trim();
            const email = document.getElementById('contactEmail').value.trim();
            const phone = document.getElementById('contactPhone').value.trim();
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('contactMessage').value.trim();
            
            let errors = [];
            
            if (name.length < 2) errors.push('Please enter your full name');
            if (!email.includes('@') || !email.includes('.')) errors.push('Please enter a valid email');
            if (phone.length < 10) errors.push('Please enter a valid phone number');
            if (subject === '') errors.push('Please select a message type');
            if (message.length < 10) errors.push('Please provide more details');
            
            if (errors.length > 0) {
                showErrors(errors);
            } else {
                processContact(name, email, phone, subject, message);
            }
        });
    }
});

// Show error messages
function showErrors(errors) {
    const errorDiv = document.getElementById('errorMessages');
    if (errorDiv) {
        errorDiv.innerHTML = errors.map(err => `<p style="color: red;">❌ ${err}</p>`).join('');
        errorDiv.style.display = 'block';
    }
}

// Process Enquiry - Shows cost & availability
function processEnquiry(name, email, phone, service, message) {
    const services = {
        'building': { cost: 'R500,000 - R2,000,000', timeline: '3-6 months' },
        'renovations': { cost: 'R100,000 - R500,000', timeline: '1-3 months' },
        'plumbing': { cost: 'R5,000 - R50,000', timeline: '1-2 weeks' },
        'electrical': { cost: 'R8,000 - R80,000', timeline: '1-3 weeks' },
        'roofing': { cost: 'R30,000 - R200,000', timeline: '2-4 weeks' }
    };
    
    const serviceInfo = services[service] || { cost: 'Please contact for quote', timeline: 'Varies' };
    
    const responseDiv = document.getElementById('responseMessage');
    if (responseDiv) {
        responseDiv.innerHTML = `
            <div style="background: #e8f5e9; padding: 20px; border-radius: 8px; border: 2px solid #4CAF50;">
                <h3>✅ Thank you, ${name}!</h3>
                <p><strong>Service:</strong> ${service.charAt(0).toUpperCase() + service.slice(1)}</p>
                <p><strong>Estimated Cost:</strong> ${serviceInfo.cost}</p>
                <p><strong>Timeline:</strong> ${serviceInfo.timeline}</p>
                <p><strong>Availability:</strong> We will contact you within 24 hours</p>
                <p style="margin-top: 10px; font-size: 14px;">We'll respond to: ${email} or ${phone}</p>
            </div>
        `;
        responseDiv.style.display = 'block';
    }
}

// Process Contact - Prepares email
function processContact(name, email, phone, subject, message) {
    const mailtoLink = `mailto:info@constructioncompany.co.za?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(
        `Name: ${name}\nEmail: ${email}\nPhone: ${phone}\nSubject: ${subject}\n\nMessage:\n${message}`
    )}`;
    
    // Show success message
    const responseDiv = document.getElementById('contactResponse');
    if (responseDiv) {
        responseDiv.innerHTML = `
            <div style="background: #e3f2fd; padding: 20px; border-radius: 8px; border: 2px solid #2196F3;">
                <h3>✅ Message Ready!</h3>
                <p>Your message has been compiled. Click the button below to send:</p>
                <a href="${mailtoLink}" class="send-email-btn" style="display: inline-block; background: #2196F3; color: white; padding: 12px 30px; border-radius: 5px; text-decoration: none; margin-top: 10px;">
                    📧 Send Email
                </a>
            </div>
        `;
        responseDiv.style.display = 'block';
    }
}